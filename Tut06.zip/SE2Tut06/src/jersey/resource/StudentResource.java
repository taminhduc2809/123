package jersey.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Student;
import jersey.service.Service;

@Path("/student")
public class StudentResource {
	private Service Service = new Service();	
	
	@GET
	@Produces(MediaType.APPLICATION_XML) 
	public List<Student> getStudent() {
		return Service.getAllStudents();
	}
	
}
