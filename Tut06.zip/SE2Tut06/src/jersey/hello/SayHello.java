package jersey.hello;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jersey.model.Student;
import jersey.service.Service;

@Path("/students")
public class SayHello {
	private Service sS = new Service();
	private List<Student> list = sS.getAllStudents();
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayPlainTextHello() {
		String text = "Software Engineering 2 - FIT HANU";
		return text;
	}
	@GET
	@Path("/1")
	@Produces(MediaType.TEXT_PLAIN)
	public String getFirstStu() {
		
		return list.get(0).toString();
	}
	@GET
	@Path("/2")
	@Produces(MediaType.TEXT_PLAIN)
	public String getSecondStu() {
		return list.get(1).toString();
	}
	
}

