package jersey.service;

import java.util.ArrayList;
import java.util.List;

import jersey.model.Champion;
import jersey.model.Game;
import jersey.model.Student;

public class Service {
	public List<Student> getAllStudents() {
		Student s1 = new Student (1,"Hoang Tuan", "0912345678");
		Student s2 = new Student (2,"Phuong Linh", "0986868686");
		List<Student> list = new ArrayList<Student>();
		list.add(s1);
		list.add(s2);
		return list;
	}
	public List<Champion> getAllChampions() {
		Champion s1 = new Champion (1,"Kalista", "Shadow Isle");
		Champion s2 = new Champion (2,"Nasus", "Shurima");
		Champion s3 = new Champion (3,"Karma", "Ionia");
		List<Champion> list = new ArrayList<Champion>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		return list;
	}
	public List<Game> getAllGames() {
		Game s1 = new Game (1,"LOR", "TCG");
		Game s2 = new Game (2,"LOL", "MOBA");
		Game s3 = new Game (3,"Valorant", "FPS");
		List<Game> list = new ArrayList<Game>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		return list;
	}
}
