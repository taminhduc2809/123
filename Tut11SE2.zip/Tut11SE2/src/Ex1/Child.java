package Ex1;

public class Child extends Person {

	public Child(String name, int age) throws IllegalArgumentException {		
		super(name, age);
		if (age < 1) {
			throw new IllegalArgumentException("Age must be positive");
		} else if (age > 15) {
			throw new IllegalArgumentException("Age must be <=15");
		}
	}

	public void setAge(int age) {
		if (age < 1) {
			throw new IllegalArgumentException("Age must be positive");
		} else if (age > 15) {
			throw new IllegalArgumentException("Age must be <=15");
		}
		super.setAge(age);;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(String.format("Name: %s, Age: %d", this.getName(), this.getAge()));

		return sb.toString();
	}

}
