package Ex3;

public class Worker extends Human {

	private double weekSalary;
	private int hoursPerDay;

	public Worker(String firstName, String lastName, double weekSalary, int hoursPerDay) {
		super(firstName, lastName);

		this.setWeekSalary(weekSalary);
		this.setHoursPerDay(hoursPerDay);
	}

	@Override
	public void setLastName(String lastName) {

		if (lastName.length() <= 3) {
			throw new IllegalArgumentException("Expected length more than 3\r\n" + "symbols!Argument: lastName");
		}

		super.lastName = lastName;
	}

	public double getWeekSalary() {
		return weekSalary;
	}

	public void setWeekSalary(double weekSalary) {
		if (weekSalary <= 10) {
			throw new IllegalArgumentException("\"Expected value mismatch!Argumen weekSalary");
		}

		this.weekSalary = weekSalary;
	}

	public int getHoursPerDay() {
		return hoursPerDay;
	}

	public void setHoursPerDay(int hoursPerDay) {
		if (hoursPerDay < 1 || hoursPerDay > 12) {
			throw new IllegalArgumentException("\"Expected value mismatch!Argument: workHoursPerDay");
		}

		this.hoursPerDay = hoursPerDay;
	}

}
