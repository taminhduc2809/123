package Ex3;

public class Human {
	protected String firstName;
	protected String lastName;

	public Human(String firstName, String lastName) {
		super();
		this.setFirstName(firstName);
		this.setLastName(lastName);
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		String firstChar = firstName.charAt(0) + "";
		if (!firstChar.toUpperCase().equals(firstChar)) {
			throw new IllegalArgumentException("Expected upper case letter!Argument: FirstName");
		}
		if (firstName.length() <= 4) {
			throw new IllegalArgumentException("Expected length at least 4 symbols!Argument: firstName");
		}

		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		String firstChar = lastName.charAt(0) + "";
		if (!firstChar.toUpperCase().equals(firstChar)) {
			throw new IllegalArgumentException("Expected upper case letter!Argument: LastName");
		}
		
		if (lastName.length() <= 3) {
			throw new IllegalArgumentException("Expected length at least 3 symbols!Argument: lastName");
		}
		
		this.lastName = lastName;
	}

}
