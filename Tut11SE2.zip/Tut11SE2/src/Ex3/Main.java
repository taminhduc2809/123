package Ex3;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Input firstName: ");
			String firstName = sc.next();
			System.out.println("Input lastName: ");
			String lastName = sc.next();
			System.out.println("Input facultyNumber ");
			String facultyNumber = sc.next();
			
			Student student = new Student(firstName, lastName, facultyNumber);
			System.out.println(student.toString());
		}catch (Exception e) {
			System.err.println(e.getMessage());
		}
		
		
	}
}
