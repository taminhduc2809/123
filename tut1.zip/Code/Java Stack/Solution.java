import java.util.Scanner;
import java.util.Stack;

public class Solution {
    public static void main(String[] argh) {
        Scanner sc = new Scanner(System.in);
        Stack<Character> ch = new Stack<>();
        while (sc.hasNext()) {
            ch.clear();
            boolean isTrue = true;
            String input = sc.next();
            for (int i = 0; i < input.length(); i++) {
                if (input.charAt(i) == '[' || input.charAt(i) == '{' || input.charAt(i) == '(') {
                    ch.push(input.charAt(i));
                    isTrue = false;
                } else if (input.charAt(i) == ']') {
                    if (ch.isEmpty()) {
                        isTrue = false;
                        break;
                    }
                    char temp = ch.pop();
                    if (temp != '[') {
                        isTrue = false;
                        break;
                    } else {
                        isTrue = true;
                    }
                } else if (input.charAt(i) == '}') {
                    if (ch.isEmpty()) {
                        isTrue = false;
                        break;
                    }
                    char temp = ch.pop();
                    if (temp != '{') {
                        isTrue = false;
                        break;
                    } else {
                        isTrue = true;
                    }
                } else if (input.charAt(i) == ')') {
                    if (ch.isEmpty()) {
                        isTrue = false;
                        break;
                    }
                    char temp = ch.pop();
                    if (temp != '(') {
                        isTrue = false;
                        break;
                    } else {
                        isTrue = true;
                    }
                }
            }
            if (!ch.isEmpty())
                isTrue = false;
            System.out.println(isTrue);
        }

    }
}
