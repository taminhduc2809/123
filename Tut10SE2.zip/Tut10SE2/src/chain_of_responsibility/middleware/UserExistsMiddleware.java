package chain_of_responsibility.middleware;

import chain_of_responsibility.server.Server;

/**
 * ConcreteHandler. Checks whether a user with the given credentials exists.
 */
public class UserExistsMiddleware extends Middleware {
    private Server server;

    //TO-DO: Implement the UserExistsMiddleWare() method
    public UserExistsMiddleware(Server server) {
         this.server = server;
    }

    public boolean check(String email, String password) {
    	//TO-DO: Check for invalid email => show error message then return false
        if (!email.contains("@")) {
        	System.err.println("Wrong email format");
        }
        //TO-DO: Check for invalid password for an email => show error message then return false
        if (password.length() < 6) {
        	System.err.println("Too short password");
        }
        return checkNext(email, password);
    }
}