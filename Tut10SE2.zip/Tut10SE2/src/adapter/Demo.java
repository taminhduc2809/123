package adapter;

import adapter.adapter.SquarePegAdapter;
import adapter.round.RoundHole;
import adapter.round.RoundPeg;
import adapter.square.SquarePeg;

/**
 * Somewhere in client code...
 */
public class Demo {
	public static void main(String[] args) {
		// TO-DO: Create 2 instances of RoundHole and RoundPeg with same radius
		RoundHole roundHole = new RoundHole(100);
		RoundPeg roundPeg = new RoundPeg(100);
		// TO-DO: If RoundHole instance can "fits" with RoundPeg instance => show a
		// message
		System.out.println("RoundHole instance can fits with RoundPeg0? : " + roundHole.fits(roundPeg));		
		// TO-DO: Create 2 instances of SquarePeg with 2 different widths
		SquarePeg peg1 = new SquarePeg(50);
		SquarePeg peg2 = new SquarePeg(100);
		// Note: You can't make RoundHole instance "fit" with SquarePeg instance
		// Therefore, we need to use Adapter for solving the problem.
		SquarePegAdapter aPeg1 = new SquarePegAdapter(peg1);
		SquarePegAdapter aPeg2 = new SquarePegAdapter(peg2);
		System.out.println("RoundHole instance can fits with RoundPeg1? : " + roundHole.fits(aPeg1));	
		System.out.println("RoundHole instance can fits with RoundPeg2? : " + roundHole.fits(aPeg2));	
		// TO-DO: Create 2 corresponding instances of SquarePegAdapter
		SquarePegAdapter aPeg3 = new SquarePegAdapter(peg1);
		SquarePegAdapter aPeg4 = new SquarePegAdapter(peg2);
		// TO-DO: If the RoundHole instance can "fits" with "small" RoundPegAdapter
		// instance
		// show a suitable message

		// TO-DO: If the RoundHole instance can not "fits" with "big" RoundPegAdapter
		// instance
		// show a suitable message
	}
}