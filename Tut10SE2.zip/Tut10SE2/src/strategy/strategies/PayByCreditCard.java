package strategy.strategies;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 * Concrete strategy. Implements credit card payment method.
 */
public class PayByCreditCard implements PayStrategy {
    private final BufferedReader READER = new BufferedReader(new InputStreamReader(System.in));
    private CreditCard card;

    /**
     * Collect credit card data.
     */
    @Override
    public void collectPaymentDetails() {
    	//TO-DO: Add 'try-catch' block to catch the IO error
    	
    	//TO-DO: Ask for card number, expiration date, CVV code then save them to suitable variables
        try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Card number:");
			String card = sc.nextLine();
			System.out.println("Expiration Date:");
			String date = sc.nextLine();
			System.out.println("CVV code:");
			String code = sc.nextLine();
			this.card = new CreditCard(card, date, code);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //TO-DO: Validate credit card number...
        
    }

    //TO-DO: Implement the pay() method
    /**
     * After card validation we can charge customer's credit card.
     */
    @Override
    public boolean pay(int paymentAmount) {
    	/*if 'cardIsPresent' => display a message 
    	to show that customer is paying with Credit Card with money amount
    	then reduce the card amount with that number
    	finally return true else return false */
    	if(cardIsPresent()) {
    		System.out.println("U are paying with Credit: " + paymentAmount);
    		card.setAmount(card.getAmount()-paymentAmount);
    		return true;
    	}
    	return false;
    }

    private boolean cardIsPresent() {
        return card != null;
    }
}
